﻿using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace ApiTarefas.Controllers
{
    [ApiController]
    [Route("tarefas")]
    public class TarefaController : Controller
    {
        [HttpGet]
        public IActionResult ListasTarefas()
        {
            var lista = Tarefas();
            return Ok(lista);
        }

        [HttpGet("usuario")]
        public IActionResult Usuario()
        {
            return Ok("luanmateus2002@gmail.com");
        }

        [HttpPost]
        public IActionResult CriarTarefas([ FromBody] Tarefa item )
        {
            var tarefa = new Tarefa();
            tarefa.Id = item.Id;
            tarefa.Descricao = item.Descricao;

            var lista = Tarefas();
            lista.Add(tarefa);

            return Ok(tarefa);
        }
        private List<Tarefa> Tarefas()
        {
            List<Tarefa> lista = new List<Tarefa>()
            {
               new Tarefa { Id = 1, Descricao = " Estudo de API 1"},
               new Tarefa { Id = 2, Descricao = " Estudo de API 2"},
               new Tarefa { Id = 3, Descricao = " Estudo de API 3"},

            };

            lista.Add(new Tarefa { Id = 4, Descricao = "Estudo de API 4" });
            lista.Add(new Tarefa { Id = 5, Descricao = "Estudo de API 5" });
            


            return lista;
            
        }

    }
}
